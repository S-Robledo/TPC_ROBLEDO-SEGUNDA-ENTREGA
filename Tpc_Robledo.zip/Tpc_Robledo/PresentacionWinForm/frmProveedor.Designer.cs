﻿namespace PresentacionWinForm
{
    partial class frmProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBajaProveedor = new System.Windows.Forms.Button();
            this.btnModificacionProveedor = new System.Windows.Forms.Button();
            this.btnAltaProveedor = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBajaProveedor
            // 
            this.btnBajaProveedor.Location = new System.Drawing.Point(12, 114);
            this.btnBajaProveedor.Name = "btnBajaProveedor";
            this.btnBajaProveedor.Size = new System.Drawing.Size(100, 45);
            this.btnBajaProveedor.TabIndex = 5;
            this.btnBajaProveedor.Text = "Baja";
            this.btnBajaProveedor.UseVisualStyleBackColor = true;
            this.btnBajaProveedor.Click += new System.EventHandler(this.btnBajaProveedor_Click);
            // 
            // btnModificacionProveedor
            // 
            this.btnModificacionProveedor.Location = new System.Drawing.Point(12, 63);
            this.btnModificacionProveedor.Name = "btnModificacionProveedor";
            this.btnModificacionProveedor.Size = new System.Drawing.Size(100, 45);
            this.btnModificacionProveedor.TabIndex = 4;
            this.btnModificacionProveedor.Text = "Modificacion";
            this.btnModificacionProveedor.UseVisualStyleBackColor = true;
            this.btnModificacionProveedor.Click += new System.EventHandler(this.btnModificacionProveedor_Click);
            // 
            // btnAltaProveedor
            // 
            this.btnAltaProveedor.Location = new System.Drawing.Point(12, 12);
            this.btnAltaProveedor.Name = "btnAltaProveedor";
            this.btnAltaProveedor.Size = new System.Drawing.Size(100, 45);
            this.btnAltaProveedor.TabIndex = 3;
            this.btnAltaProveedor.Text = "Alta";
            this.btnAltaProveedor.UseVisualStyleBackColor = true;
            this.btnAltaProveedor.Click += new System.EventHandler(this.btnAltaProveedor_Click);
            // 
            // frmProveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 461);
            this.Controls.Add(this.btnBajaProveedor);
            this.Controls.Add(this.btnModificacionProveedor);
            this.Controls.Add(this.btnAltaProveedor);
            this.Name = "frmProveedor";
            this.Text = "Ventana Proveedor";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBajaProveedor;
        private System.Windows.Forms.Button btnModificacionProveedor;
        private System.Windows.Forms.Button btnAltaProveedor;
    }
}