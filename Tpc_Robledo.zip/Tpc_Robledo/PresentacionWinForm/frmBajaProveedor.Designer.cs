﻿namespace PresentacionWinForm
{
    partial class frmBajaProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.lblPiso = new System.Windows.Forms.Label();
            this.lblLocalidad = new System.Windows.Forms.Label();
            this.txtCuitProveedor = new System.Windows.Forms.TextBox();
            this.lblNumero = new System.Windows.Forms.Label();
            this.lblTelefonoProveedor = new System.Windows.Forms.Label();
            this.lblMailProveedor = new System.Windows.Forms.Label();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.lblCuitProveedor = new System.Windows.Forms.Label();
            this.lblRazonSocial = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.lblContenidoRazonSocial = new System.Windows.Forms.Label();
            this.lblContenidoDireccion = new System.Windows.Forms.Label();
            this.lblContenidoNumero = new System.Windows.Forms.Label();
            this.lblContenidoLocalidad = new System.Windows.Forms.Label();
            this.lblContenidoPiso = new System.Windows.Forms.Label();
            this.lblContenidoDepartamento = new System.Windows.Forms.Label();
            this.lblContenidoMail = new System.Windows.Forms.Label();
            this.lblContenidoTelefono = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartamento.Location = new System.Drawing.Point(232, 210);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(46, 18);
            this.lblDepartamento.TabIndex = 75;
            this.lblDepartamento.Text = "Dpto:";
            // 
            // lblPiso
            // 
            this.lblPiso.AutoSize = true;
            this.lblPiso.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPiso.Location = new System.Drawing.Point(37, 210);
            this.lblPiso.Name = "lblPiso";
            this.lblPiso.Size = new System.Drawing.Size(44, 18);
            this.lblPiso.TabIndex = 74;
            this.lblPiso.Text = "Piso:";
            // 
            // lblLocalidad
            // 
            this.lblLocalidad.AutoSize = true;
            this.lblLocalidad.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLocalidad.Location = new System.Drawing.Point(37, 182);
            this.lblLocalidad.Name = "lblLocalidad";
            this.lblLocalidad.Size = new System.Drawing.Size(81, 18);
            this.lblLocalidad.TabIndex = 67;
            this.lblLocalidad.Text = "Localidad:";
            // 
            // txtCuitProveedor
            // 
            this.txtCuitProveedor.Location = new System.Drawing.Point(179, 16);
            this.txtCuitProveedor.Name = "txtCuitProveedor";
            this.txtCuitProveedor.Size = new System.Drawing.Size(181, 20);
            this.txtCuitProveedor.TabIndex = 65;
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero.Location = new System.Drawing.Point(37, 156);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(67, 18);
            this.lblNumero.TabIndex = 64;
            this.lblNumero.Text = "Numero:";
            // 
            // lblTelefonoProveedor
            // 
            this.lblTelefonoProveedor.AutoSize = true;
            this.lblTelefonoProveedor.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefonoProveedor.Location = new System.Drawing.Point(26, 270);
            this.lblTelefonoProveedor.Name = "lblTelefonoProveedor";
            this.lblTelefonoProveedor.Size = new System.Drawing.Size(70, 18);
            this.lblTelefonoProveedor.TabIndex = 63;
            this.lblTelefonoProveedor.Text = "Telefono:";
            // 
            // lblMailProveedor
            // 
            this.lblMailProveedor.AutoSize = true;
            this.lblMailProveedor.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMailProveedor.Location = new System.Drawing.Point(25, 244);
            this.lblMailProveedor.Name = "lblMailProveedor";
            this.lblMailProveedor.Size = new System.Drawing.Size(41, 18);
            this.lblMailProveedor.TabIndex = 62;
            this.lblMailProveedor.Text = "Mail:";
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDireccion.Location = new System.Drawing.Point(37, 130);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(79, 18);
            this.lblDireccion.TabIndex = 61;
            this.lblDireccion.Text = "Direccion:";
            // 
            // lblCuitProveedor
            // 
            this.lblCuitProveedor.AutoSize = true;
            this.lblCuitProveedor.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCuitProveedor.Location = new System.Drawing.Point(25, 15);
            this.lblCuitProveedor.Name = "lblCuitProveedor";
            this.lblCuitProveedor.Size = new System.Drawing.Size(40, 18);
            this.lblCuitProveedor.TabIndex = 59;
            this.lblCuitProveedor.Text = "Cuit:";
            // 
            // lblRazonSocial
            // 
            this.lblRazonSocial.AutoSize = true;
            this.lblRazonSocial.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRazonSocial.Location = new System.Drawing.Point(25, 41);
            this.lblRazonSocial.Name = "lblRazonSocial";
            this.lblRazonSocial.Size = new System.Drawing.Size(104, 18);
            this.lblRazonSocial.TabIndex = 57;
            this.lblRazonSocial.Text = "Razon Social:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(208, 400);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(100, 45);
            this.btnCancelar.TabIndex = 56;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(69, 400);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(100, 45);
            this.btnAceptar.TabIndex = 55;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            // 
            // lblContenidoRazonSocial
            // 
            this.lblContenidoRazonSocial.AutoSize = true;
            this.lblContenidoRazonSocial.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoRazonSocial.Location = new System.Drawing.Point(179, 43);
            this.lblContenidoRazonSocial.Name = "lblContenidoRazonSocial";
            this.lblContenidoRazonSocial.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoRazonSocial.TabIndex = 77;
            // 
            // lblContenidoDireccion
            // 
            this.lblContenidoDireccion.AutoSize = true;
            this.lblContenidoDireccion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoDireccion.Location = new System.Drawing.Point(179, 134);
            this.lblContenidoDireccion.Name = "lblContenidoDireccion";
            this.lblContenidoDireccion.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoDireccion.TabIndex = 78;
            // 
            // lblContenidoNumero
            // 
            this.lblContenidoNumero.AutoSize = true;
            this.lblContenidoNumero.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoNumero.Location = new System.Drawing.Point(179, 160);
            this.lblContenidoNumero.Name = "lblContenidoNumero";
            this.lblContenidoNumero.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoNumero.TabIndex = 79;
            // 
            // lblContenidoLocalidad
            // 
            this.lblContenidoLocalidad.AutoSize = true;
            this.lblContenidoLocalidad.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoLocalidad.Location = new System.Drawing.Point(179, 186);
            this.lblContenidoLocalidad.Name = "lblContenidoLocalidad";
            this.lblContenidoLocalidad.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoLocalidad.TabIndex = 80;
            // 
            // lblContenidoPiso
            // 
            this.lblContenidoPiso.AutoSize = true;
            this.lblContenidoPiso.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoPiso.Location = new System.Drawing.Point(148, 214);
            this.lblContenidoPiso.Name = "lblContenidoPiso";
            this.lblContenidoPiso.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoPiso.TabIndex = 81;
            // 
            // lblContenidoDepartamento
            // 
            this.lblContenidoDepartamento.AutoSize = true;
            this.lblContenidoDepartamento.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoDepartamento.Location = new System.Drawing.Point(294, 214);
            this.lblContenidoDepartamento.Name = "lblContenidoDepartamento";
            this.lblContenidoDepartamento.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoDepartamento.TabIndex = 82;
            // 
            // lblContenidoMail
            // 
            this.lblContenidoMail.AutoSize = true;
            this.lblContenidoMail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoMail.Location = new System.Drawing.Point(148, 248);
            this.lblContenidoMail.Name = "lblContenidoMail";
            this.lblContenidoMail.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoMail.TabIndex = 83;
            // 
            // lblContenidoTelefono
            // 
            this.lblContenidoTelefono.AutoSize = true;
            this.lblContenidoTelefono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoTelefono.Location = new System.Drawing.Point(148, 274);
            this.lblContenidoTelefono.Name = "lblContenidoTelefono";
            this.lblContenidoTelefono.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoTelefono.TabIndex = 84;
            // 
            // frmBajaProveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 461);
            this.Controls.Add(this.lblContenidoTelefono);
            this.Controls.Add(this.lblContenidoMail);
            this.Controls.Add(this.lblContenidoDepartamento);
            this.Controls.Add(this.lblContenidoPiso);
            this.Controls.Add(this.lblContenidoLocalidad);
            this.Controls.Add(this.lblContenidoNumero);
            this.Controls.Add(this.lblContenidoDireccion);
            this.Controls.Add(this.lblContenidoRazonSocial);
            this.Controls.Add(this.lblDepartamento);
            this.Controls.Add(this.lblPiso);
            this.Controls.Add(this.lblLocalidad);
            this.Controls.Add(this.txtCuitProveedor);
            this.Controls.Add(this.lblNumero);
            this.Controls.Add(this.lblTelefonoProveedor);
            this.Controls.Add(this.lblMailProveedor);
            this.Controls.Add(this.lblDireccion);
            this.Controls.Add(this.lblCuitProveedor);
            this.Controls.Add(this.lblRazonSocial);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Name = "frmBajaProveedor";
            this.Text = "frmBajaProveedor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDepartamento;
        private System.Windows.Forms.Label lblPiso;
        private System.Windows.Forms.Label lblLocalidad;
        private System.Windows.Forms.TextBox txtCuitProveedor;
        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.Label lblTelefonoProveedor;
        private System.Windows.Forms.Label lblMailProveedor;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.Label lblCuitProveedor;
        private System.Windows.Forms.Label lblRazonSocial;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Label lblContenidoRazonSocial;
        private System.Windows.Forms.Label lblContenidoDireccion;
        private System.Windows.Forms.Label lblContenidoNumero;
        private System.Windows.Forms.Label lblContenidoLocalidad;
        private System.Windows.Forms.Label lblContenidoPiso;
        private System.Windows.Forms.Label lblContenidoDepartamento;
        private System.Windows.Forms.Label lblContenidoMail;
        private System.Windows.Forms.Label lblContenidoTelefono;
    }
}