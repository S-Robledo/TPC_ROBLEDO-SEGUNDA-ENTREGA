﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentacionWinForm
{
    public partial class frmCliente : Form
    {
        public frmCliente()
        {
            InitializeComponent();
        }

        private void btnAltaCliente_Click(object sender, EventArgs e)
        {
            frmAltaCliente clienteNuevo=new frmAltaCliente();
            clienteNuevo.ShowDialog();
            
        }

        private void btnModificacionCliente_Click(object sender, EventArgs e)
        {
            ModificacionCliente clienteModificar = new ModificacionCliente();
            clienteModificar.ShowDialog();
        }

        private void btnBajaCliente_Click(object sender, EventArgs e)
        {
            frmBajaCliente clienteBaja = new frmBajaCliente();
            clienteBaja.ShowDialog();
        }
    }
}
