﻿namespace PresentacionWinForm
{
    partial class frmCompra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIngreseProveedor = new System.Windows.Forms.Label();
            this.txtCuitProveedor = new System.Windows.Forms.TextBox();
            this.lblCuitProveedor = new System.Windows.Forms.Label();
            this.lblContenidoRazonSocial = new System.Windows.Forms.Label();
            this.lblRazonSocial = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblCategoria = new System.Windows.Forms.Label();
            this.lblPrecioLista = new System.Windows.Forms.Label();
            this.lblPorcentajeGanancia = new System.Windows.Forms.Label();
            this.lblFechaVencimiento = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.txtCategoria = new System.Windows.Forms.TextBox();
            this.txtPrecioLista = new System.Windows.Forms.TextBox();
            this.txtPorcentajeGanancia = new System.Windows.Forms.TextBox();
            this.txtFechaVencimiento = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // lblIngreseProveedor
            // 
            this.lblIngreseProveedor.AutoSize = true;
            this.lblIngreseProveedor.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIngreseProveedor.Location = new System.Drawing.Point(23, 9);
            this.lblIngreseProveedor.Name = "lblIngreseProveedor";
            this.lblIngreseProveedor.Size = new System.Drawing.Size(140, 18);
            this.lblIngreseProveedor.TabIndex = 0;
            this.lblIngreseProveedor.Text = "Ingrese Proveedor:";
            // 
            // txtCuitProveedor
            // 
            this.txtCuitProveedor.Location = new System.Drawing.Point(178, 38);
            this.txtCuitProveedor.Name = "txtCuitProveedor";
            this.txtCuitProveedor.Size = new System.Drawing.Size(181, 20);
            this.txtCuitProveedor.TabIndex = 67;
            // 
            // lblCuitProveedor
            // 
            this.lblCuitProveedor.AutoSize = true;
            this.lblCuitProveedor.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCuitProveedor.Location = new System.Drawing.Point(23, 37);
            this.lblCuitProveedor.Name = "lblCuitProveedor";
            this.lblCuitProveedor.Size = new System.Drawing.Size(40, 18);
            this.lblCuitProveedor.TabIndex = 66;
            this.lblCuitProveedor.Text = "Cuit:";
            // 
            // lblContenidoRazonSocial
            // 
            this.lblContenidoRazonSocial.AutoSize = true;
            this.lblContenidoRazonSocial.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblContenidoRazonSocial.Location = new System.Drawing.Point(177, 69);
            this.lblContenidoRazonSocial.Name = "lblContenidoRazonSocial";
            this.lblContenidoRazonSocial.Size = new System.Drawing.Size(2, 15);
            this.lblContenidoRazonSocial.TabIndex = 79;
            // 
            // lblRazonSocial
            // 
            this.lblRazonSocial.AutoSize = true;
            this.lblRazonSocial.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRazonSocial.Location = new System.Drawing.Point(23, 67);
            this.lblRazonSocial.Name = "lblRazonSocial";
            this.lblRazonSocial.Size = new System.Drawing.Size(104, 18);
            this.lblRazonSocial.TabIndex = 78;
            this.lblRazonSocial.Text = "Razon Social:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(23, 106);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(135, 18);
            this.lblNombre.TabIndex = 80;
            this.lblNombre.Text = "Producto Nombre:";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarca.Location = new System.Drawing.Point(23, 143);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(56, 18);
            this.lblMarca.TabIndex = 81;
            this.lblMarca.Text = "Marca:";
            // 
            // lblCategoria
            // 
            this.lblCategoria.AutoSize = true;
            this.lblCategoria.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoria.Location = new System.Drawing.Point(23, 177);
            this.lblCategoria.Name = "lblCategoria";
            this.lblCategoria.Size = new System.Drawing.Size(82, 18);
            this.lblCategoria.TabIndex = 82;
            this.lblCategoria.Text = "Categoria:";
            // 
            // lblPrecioLista
            // 
            this.lblPrecioLista.AutoSize = true;
            this.lblPrecioLista.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecioLista.Location = new System.Drawing.Point(23, 209);
            this.lblPrecioLista.Name = "lblPrecioLista";
            this.lblPrecioLista.Size = new System.Drawing.Size(96, 18);
            this.lblPrecioLista.TabIndex = 83;
            this.lblPrecioLista.Text = "Precio Lista:";
            // 
            // lblPorcentajeGanancia
            // 
            this.lblPorcentajeGanancia.AutoSize = true;
            this.lblPorcentajeGanancia.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorcentajeGanancia.Location = new System.Drawing.Point(23, 240);
            this.lblPorcentajeGanancia.Name = "lblPorcentajeGanancia";
            this.lblPorcentajeGanancia.Size = new System.Drawing.Size(158, 18);
            this.lblPorcentajeGanancia.TabIndex = 85;
            this.lblPorcentajeGanancia.Text = "Porcentaje Ganancia:";
            // 
            // lblFechaVencimiento
            // 
            this.lblFechaVencimiento.AutoSize = true;
            this.lblFechaVencimiento.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaVencimiento.Location = new System.Drawing.Point(23, 273);
            this.lblFechaVencimiento.Name = "lblFechaVencimiento";
            this.lblFechaVencimiento.Size = new System.Drawing.Size(146, 18);
            this.lblFechaVencimiento.TabIndex = 86;
            this.lblFechaVencimiento.Text = "Fecha Vencimiento:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(210, 404);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(100, 45);
            this.btnCancelar.TabIndex = 88;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(71, 404);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(100, 45);
            this.btnAceptar.TabIndex = 87;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(178, 107);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(181, 20);
            this.txtNombre.TabIndex = 89;
            // 
            // txtMarca
            // 
            this.txtMarca.Location = new System.Drawing.Point(178, 144);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.Size = new System.Drawing.Size(181, 20);
            this.txtMarca.TabIndex = 90;
            // 
            // txtCategoria
            // 
            this.txtCategoria.Location = new System.Drawing.Point(178, 178);
            this.txtCategoria.Name = "txtCategoria";
            this.txtCategoria.Size = new System.Drawing.Size(181, 20);
            this.txtCategoria.TabIndex = 91;
            // 
            // txtPrecioLista
            // 
            this.txtPrecioLista.Location = new System.Drawing.Point(178, 210);
            this.txtPrecioLista.Name = "txtPrecioLista";
            this.txtPrecioLista.Size = new System.Drawing.Size(181, 20);
            this.txtPrecioLista.TabIndex = 92;
            // 
            // txtPorcentajeGanancia
            // 
            this.txtPorcentajeGanancia.Location = new System.Drawing.Point(178, 241);
            this.txtPorcentajeGanancia.Name = "txtPorcentajeGanancia";
            this.txtPorcentajeGanancia.Size = new System.Drawing.Size(181, 20);
            this.txtPorcentajeGanancia.TabIndex = 93;
            // 
            // txtFechaVencimiento
            // 
            this.txtFechaVencimiento.Location = new System.Drawing.Point(178, 274);
            this.txtFechaVencimiento.Name = "txtFechaVencimiento";
            this.txtFechaVencimiento.Size = new System.Drawing.Size(181, 20);
            this.txtFechaVencimiento.TabIndex = 94;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(346, 321);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel1.TabIndex = 95;
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(425, 107);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(121, 97);
            this.treeView1.TabIndex = 96;
            // 
            // frmCompra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 461);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.txtFechaVencimiento);
            this.Controls.Add(this.txtPorcentajeGanancia);
            this.Controls.Add(this.txtPrecioLista);
            this.Controls.Add(this.txtCategoria);
            this.Controls.Add(this.txtMarca);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.lblFechaVencimiento);
            this.Controls.Add(this.lblPorcentajeGanancia);
            this.Controls.Add(this.lblPrecioLista);
            this.Controls.Add(this.lblCategoria);
            this.Controls.Add(this.lblMarca);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblContenidoRazonSocial);
            this.Controls.Add(this.lblRazonSocial);
            this.Controls.Add(this.txtCuitProveedor);
            this.Controls.Add(this.lblCuitProveedor);
            this.Controls.Add(this.lblIngreseProveedor);
            this.Name = "frmCompra";
            this.Text = "Ventana Compras";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIngreseProveedor;
        private System.Windows.Forms.TextBox txtCuitProveedor;
        private System.Windows.Forms.Label lblCuitProveedor;
        private System.Windows.Forms.Label lblContenidoRazonSocial;
        private System.Windows.Forms.Label lblRazonSocial;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblCategoria;
        private System.Windows.Forms.Label lblPrecioLista;
        private System.Windows.Forms.Label lblPorcentajeGanancia;
        private System.Windows.Forms.Label lblFechaVencimiento;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.TextBox txtCategoria;
        private System.Windows.Forms.TextBox txtPrecioLista;
        private System.Windows.Forms.TextBox txtPorcentajeGanancia;
        private System.Windows.Forms.TextBox txtFechaVencimiento;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TreeView treeView1;
    }
}