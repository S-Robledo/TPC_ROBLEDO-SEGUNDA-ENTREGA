﻿namespace PresentacionWinForm
{
    partial class frmBajaCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.txtDniCliente = new System.Windows.Forms.TextBox();
            this.lblDniCliente = new System.Windows.Forms.Label();
            this.lblPisoDireccion = new System.Windows.Forms.Label();
            this.lblLocalidadDireccion = new System.Windows.Forms.Label();
            this.lblNombreDireccion = new System.Windows.Forms.Label();
            this.lblNumeroDireccion = new System.Windows.Forms.Label();
            this.lblTelefonoCliente = new System.Windows.Forms.Label();
            this.lblMailCliente = new System.Windows.Forms.Label();
            this.lblNacionalidadCliente = new System.Windows.Forms.Label();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.lblFechaNacimiento = new System.Windows.Forms.Label();
            this.lblApellidoCliente = new System.Windows.Forms.Label();
            this.lblNombreCliente = new System.Windows.Forms.Label();
            this.lblCuilCliente = new System.Windows.Forms.Label();
            this.lblContenidoCuil = new System.Windows.Forms.Label();
            this.lblContenidoNombre = new System.Windows.Forms.Label();
            this.lblContenidoApellido = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblDepartamento = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(205, 404);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(100, 45);
            this.btnCancelar.TabIndex = 26;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(66, 404);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(100, 45);
            this.btnAceptar.TabIndex = 25;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            // 
            // txtDniCliente
            // 
            this.txtDniCliente.Location = new System.Drawing.Point(173, 12);
            this.txtDniCliente.Name = "txtDniCliente";
            this.txtDniCliente.Size = new System.Drawing.Size(181, 20);
            this.txtDniCliente.TabIndex = 28;
            // 
            // lblDniCliente
            // 
            this.lblDniCliente.AutoSize = true;
            this.lblDniCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDniCliente.Location = new System.Drawing.Point(19, 11);
            this.lblDniCliente.Name = "lblDniCliente";
            this.lblDniCliente.Size = new System.Drawing.Size(36, 18);
            this.lblDniCliente.TabIndex = 27;
            this.lblDniCliente.Text = "Dni:";
            // 
            // lblPisoDireccion
            // 
            this.lblPisoDireccion.AutoSize = true;
            this.lblPisoDireccion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPisoDireccion.Location = new System.Drawing.Point(31, 318);
            this.lblPisoDireccion.Name = "lblPisoDireccion";
            this.lblPisoDireccion.Size = new System.Drawing.Size(44, 18);
            this.lblPisoDireccion.TabIndex = 40;
            this.lblPisoDireccion.Text = "Piso:";
            // 
            // lblLocalidadDireccion
            // 
            this.lblLocalidadDireccion.AutoSize = true;
            this.lblLocalidadDireccion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLocalidadDireccion.Location = new System.Drawing.Point(30, 291);
            this.lblLocalidadDireccion.Name = "lblLocalidadDireccion";
            this.lblLocalidadDireccion.Size = new System.Drawing.Size(81, 18);
            this.lblLocalidadDireccion.TabIndex = 39;
            this.lblLocalidadDireccion.Text = "Localidad:";
            // 
            // lblNombreDireccion
            // 
            this.lblNombreDireccion.AutoSize = true;
            this.lblNombreDireccion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreDireccion.Location = new System.Drawing.Point(31, 237);
            this.lblNombreDireccion.Name = "lblNombreDireccion";
            this.lblNombreDireccion.Size = new System.Drawing.Size(68, 18);
            this.lblNombreDireccion.TabIndex = 38;
            this.lblNombreDireccion.Text = "Nombre:";
            // 
            // lblNumeroDireccion
            // 
            this.lblNumeroDireccion.AutoSize = true;
            this.lblNumeroDireccion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeroDireccion.Location = new System.Drawing.Point(30, 265);
            this.lblNumeroDireccion.Name = "lblNumeroDireccion";
            this.lblNumeroDireccion.Size = new System.Drawing.Size(67, 18);
            this.lblNumeroDireccion.TabIndex = 37;
            this.lblNumeroDireccion.Text = "Numero:";
            // 
            // lblTelefonoCliente
            // 
            this.lblTelefonoCliente.AutoSize = true;
            this.lblTelefonoCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefonoCliente.Location = new System.Drawing.Point(19, 374);
            this.lblTelefonoCliente.Name = "lblTelefonoCliente";
            this.lblTelefonoCliente.Size = new System.Drawing.Size(70, 18);
            this.lblTelefonoCliente.TabIndex = 36;
            this.lblTelefonoCliente.Text = "Telefono:";
            // 
            // lblMailCliente
            // 
            this.lblMailCliente.AutoSize = true;
            this.lblMailCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMailCliente.Location = new System.Drawing.Point(19, 345);
            this.lblMailCliente.Name = "lblMailCliente";
            this.lblMailCliente.Size = new System.Drawing.Size(41, 18);
            this.lblMailCliente.TabIndex = 35;
            this.lblMailCliente.Text = "Mail:";
            // 
            // lblNacionalidadCliente
            // 
            this.lblNacionalidadCliente.AutoSize = true;
            this.lblNacionalidadCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNacionalidadCliente.Location = new System.Drawing.Point(19, 162);
            this.lblNacionalidadCliente.Name = "lblNacionalidadCliente";
            this.lblNacionalidadCliente.Size = new System.Drawing.Size(104, 18);
            this.lblNacionalidadCliente.TabIndex = 34;
            this.lblNacionalidadCliente.Text = "Nacionalidad:";
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDireccion.Location = new System.Drawing.Point(19, 205);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(79, 18);
            this.lblDireccion.TabIndex = 33;
            this.lblDireccion.Text = "Direccion:";
            // 
            // lblFechaNacimiento
            // 
            this.lblFechaNacimiento.AutoSize = true;
            this.lblFechaNacimiento.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNacimiento.Location = new System.Drawing.Point(19, 129);
            this.lblFechaNacimiento.Name = "lblFechaNacimiento";
            this.lblFechaNacimiento.Size = new System.Drawing.Size(161, 18);
            this.lblFechaNacimiento.TabIndex = 32;
            this.lblFechaNacimiento.Text = "Fecha de Nacimiento:";
            // 
            // lblApellidoCliente
            // 
            this.lblApellidoCliente.AutoSize = true;
            this.lblApellidoCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidoCliente.Location = new System.Drawing.Point(19, 97);
            this.lblApellidoCliente.Name = "lblApellidoCliente";
            this.lblApellidoCliente.Size = new System.Drawing.Size(69, 18);
            this.lblApellidoCliente.TabIndex = 31;
            this.lblApellidoCliente.Text = "Apellido:";
            // 
            // lblNombreCliente
            // 
            this.lblNombreCliente.AutoSize = true;
            this.lblNombreCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreCliente.Location = new System.Drawing.Point(19, 67);
            this.lblNombreCliente.Name = "lblNombreCliente";
            this.lblNombreCliente.Size = new System.Drawing.Size(68, 18);
            this.lblNombreCliente.TabIndex = 30;
            this.lblNombreCliente.Text = "Nombre:";
            // 
            // lblCuilCliente
            // 
            this.lblCuilCliente.AutoSize = true;
            this.lblCuilCliente.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCuilCliente.Location = new System.Drawing.Point(19, 39);
            this.lblCuilCliente.Name = "lblCuilCliente";
            this.lblCuilCliente.Size = new System.Drawing.Size(39, 18);
            this.lblCuilCliente.TabIndex = 29;
            this.lblCuilCliente.Text = "Cuil:";
            // 
            // lblContenidoCuil
            // 
            this.lblContenidoCuil.AutoSize = true;
            this.lblContenidoCuil.Location = new System.Drawing.Point(319, 44);
            this.lblContenidoCuil.Name = "lblContenidoCuil";
            this.lblContenidoCuil.Size = new System.Drawing.Size(0, 13);
            this.lblContenidoCuil.TabIndex = 41;
            // 
            // lblContenidoNombre
            // 
            this.lblContenidoNombre.AutoSize = true;
            this.lblContenidoNombre.Location = new System.Drawing.Point(319, 67);
            this.lblContenidoNombre.Name = "lblContenidoNombre";
            this.lblContenidoNombre.Size = new System.Drawing.Size(0, 13);
            this.lblContenidoNombre.TabIndex = 42;
            // 
            // lblContenidoApellido
            // 
            this.lblContenidoApellido.AutoSize = true;
            this.lblContenidoApellido.Location = new System.Drawing.Point(319, 101);
            this.lblContenidoApellido.Name = "lblContenidoApellido";
            this.lblContenidoApellido.Size = new System.Drawing.Size(0, 13);
            this.lblContenidoApellido.TabIndex = 43;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(319, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 44;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(319, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 45;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(319, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 46;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(319, 295);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 47;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(145, 322);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(9, 13);
            this.label8.TabIndex = 48;
            this.label8.Text = "l";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(319, 322);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(9, 13);
            this.label9.TabIndex = 49;
            this.label9.Text = "l";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(345, 349);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(9, 13);
            this.label10.TabIndex = 50;
            this.label10.Text = "l";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(313, 378);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(9, 13);
            this.label11.TabIndex = 51;
            this.label11.Text = "l";
            // 
            // lblDepartamento
            // 
            this.lblDepartamento.AutoSize = true;
            this.lblDepartamento.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartamento.Location = new System.Drawing.Point(211, 318);
            this.lblDepartamento.Name = "lblDepartamento";
            this.lblDepartamento.Size = new System.Drawing.Size(46, 18);
            this.lblDepartamento.TabIndex = 52;
            this.lblDepartamento.Text = "Dpto:";
            // 
            // BajaCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 461);
            this.Controls.Add(this.lblDepartamento);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblContenidoApellido);
            this.Controls.Add(this.lblContenidoNombre);
            this.Controls.Add(this.lblContenidoCuil);
            this.Controls.Add(this.lblPisoDireccion);
            this.Controls.Add(this.lblLocalidadDireccion);
            this.Controls.Add(this.lblNombreDireccion);
            this.Controls.Add(this.lblNumeroDireccion);
            this.Controls.Add(this.lblTelefonoCliente);
            this.Controls.Add(this.lblMailCliente);
            this.Controls.Add(this.lblNacionalidadCliente);
            this.Controls.Add(this.lblDireccion);
            this.Controls.Add(this.lblFechaNacimiento);
            this.Controls.Add(this.lblApellidoCliente);
            this.Controls.Add(this.lblNombreCliente);
            this.Controls.Add(this.lblCuilCliente);
            this.Controls.Add(this.txtDniCliente);
            this.Controls.Add(this.lblDniCliente);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Name = "BajaCliente";
            this.Text = "BajaCliente";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.TextBox txtDniCliente;
        private System.Windows.Forms.Label lblDniCliente;
        private System.Windows.Forms.Label lblPisoDireccion;
        private System.Windows.Forms.Label lblLocalidadDireccion;
        private System.Windows.Forms.Label lblNombreDireccion;
        private System.Windows.Forms.Label lblNumeroDireccion;
        private System.Windows.Forms.Label lblTelefonoCliente;
        private System.Windows.Forms.Label lblMailCliente;
        private System.Windows.Forms.Label lblNacionalidadCliente;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.Label lblFechaNacimiento;
        private System.Windows.Forms.Label lblApellidoCliente;
        private System.Windows.Forms.Label lblNombreCliente;
        private System.Windows.Forms.Label lblCuilCliente;
        private System.Windows.Forms.Label lblContenidoCuil;
        private System.Windows.Forms.Label lblContenidoNombre;
        private System.Windows.Forms.Label lblContenidoApellido;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblDepartamento;
    }
}