﻿namespace PresentacionWinForm
{
    partial class frmAltaProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGuardar = new System.Windows.Forms.Button();
            this.tbcProducto = new System.Windows.Forms.TabControl();
            this.tbpGeneral = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.tbpCaracteristicas = new System.Windows.Forms.TabPage();
            this.tbpVentas = new System.Windows.Forms.TabPage();
            this.tbpStock = new System.Windows.Forms.TabPage();
            this.tbpProveedor = new System.Windows.Forms.TabPage();
            this.tbcProducto.SuspendLayout();
            this.tbpGeneral.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(527, 337);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(100, 45);
            this.btnGuardar.TabIndex = 3;
            this.btnGuardar.Text = "Guadar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            // 
            // tbcProducto
            // 
            this.tbcProducto.Controls.Add(this.tbpGeneral);
            this.tbcProducto.Controls.Add(this.tbpCaracteristicas);
            this.tbcProducto.Controls.Add(this.tbpVentas);
            this.tbcProducto.Controls.Add(this.tbpStock);
            this.tbcProducto.Controls.Add(this.tbpProveedor);
            this.tbcProducto.Location = new System.Drawing.Point(24, 58);
            this.tbcProducto.Name = "tbcProducto";
            this.tbcProducto.SelectedIndex = 0;
            this.tbcProducto.Size = new System.Drawing.Size(603, 273);
            this.tbcProducto.TabIndex = 2;
            // 
            // tbpGeneral
            // 
            this.tbpGeneral.Controls.Add(this.label1);
            this.tbpGeneral.Location = new System.Drawing.Point(4, 22);
            this.tbpGeneral.Name = "tbpGeneral";
            this.tbpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.tbpGeneral.Size = new System.Drawing.Size(595, 247);
            this.tbpGeneral.TabIndex = 0;
            this.tbpGeneral.Text = "General";
            this.tbpGeneral.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Codigo";
            // 
            // tbpCaracteristicas
            // 
            this.tbpCaracteristicas.Location = new System.Drawing.Point(4, 22);
            this.tbpCaracteristicas.Name = "tbpCaracteristicas";
            this.tbpCaracteristicas.Padding = new System.Windows.Forms.Padding(3);
            this.tbpCaracteristicas.Size = new System.Drawing.Size(595, 247);
            this.tbpCaracteristicas.TabIndex = 1;
            this.tbpCaracteristicas.Text = "Caracteristicas";
            this.tbpCaracteristicas.UseVisualStyleBackColor = true;
            // 
            // tbpVentas
            // 
            this.tbpVentas.Location = new System.Drawing.Point(4, 22);
            this.tbpVentas.Name = "tbpVentas";
            this.tbpVentas.Padding = new System.Windows.Forms.Padding(3);
            this.tbpVentas.Size = new System.Drawing.Size(595, 247);
            this.tbpVentas.TabIndex = 2;
            this.tbpVentas.Text = "Venta";
            this.tbpVentas.UseVisualStyleBackColor = true;
            // 
            // tbpStock
            // 
            this.tbpStock.Location = new System.Drawing.Point(4, 22);
            this.tbpStock.Name = "tbpStock";
            this.tbpStock.Size = new System.Drawing.Size(595, 247);
            this.tbpStock.TabIndex = 3;
            this.tbpStock.Text = "Stock";
            this.tbpStock.UseVisualStyleBackColor = true;
            // 
            // tbpProveedor
            // 
            this.tbpProveedor.Location = new System.Drawing.Point(4, 22);
            this.tbpProveedor.Name = "tbpProveedor";
            this.tbpProveedor.Size = new System.Drawing.Size(595, 247);
            this.tbpProveedor.TabIndex = 4;
            this.tbpProveedor.Text = "Proveedor";
            this.tbpProveedor.UseVisualStyleBackColor = true;
            // 
            // frmAltaProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.tbcProducto);
            this.Name = "frmAltaProducto";
            this.Text = "frmAltaProducto";
            this.tbcProducto.ResumeLayout(false);
            this.tbpGeneral.ResumeLayout(false);
            this.tbpGeneral.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TabControl tbcProducto;
        private System.Windows.Forms.TabPage tbpGeneral;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tbpCaracteristicas;
        private System.Windows.Forms.TabPage tbpVentas;
        private System.Windows.Forms.TabPage tbpStock;
        private System.Windows.Forms.TabPage tbpProveedor;
    }
}