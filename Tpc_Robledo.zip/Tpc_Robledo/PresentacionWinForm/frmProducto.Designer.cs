﻿namespace PresentacionWinForm
{
    partial class frmProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBajaProducto = new System.Windows.Forms.Button();
            this.btnModificacionProducto = new System.Windows.Forms.Button();
            this.btnAltaProducto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBajaProducto
            // 
            this.btnBajaProducto.Location = new System.Drawing.Point(12, 114);
            this.btnBajaProducto.Name = "btnBajaProducto";
            this.btnBajaProducto.Size = new System.Drawing.Size(100, 45);
            this.btnBajaProducto.TabIndex = 5;
            this.btnBajaProducto.Text = "Baja";
            this.btnBajaProducto.UseVisualStyleBackColor = true;
            // 
            // btnModificacionProducto
            // 
            this.btnModificacionProducto.Location = new System.Drawing.Point(12, 63);
            this.btnModificacionProducto.Name = "btnModificacionProducto";
            this.btnModificacionProducto.Size = new System.Drawing.Size(100, 45);
            this.btnModificacionProducto.TabIndex = 4;
            this.btnModificacionProducto.Text = "Modificacion";
            this.btnModificacionProducto.UseVisualStyleBackColor = true;
            // 
            // btnAltaProducto
            // 
            this.btnAltaProducto.Location = new System.Drawing.Point(12, 12);
            this.btnAltaProducto.Name = "btnAltaProducto";
            this.btnAltaProducto.Size = new System.Drawing.Size(100, 45);
            this.btnAltaProducto.TabIndex = 3;
            this.btnAltaProducto.Text = "Alta";
            this.btnAltaProducto.UseVisualStyleBackColor = true;
            // 
            // frmProducto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.btnBajaProducto);
            this.Controls.Add(this.btnModificacionProducto);
            this.Controls.Add(this.btnAltaProducto);
            this.Name = "frmProducto";
            this.Text = "Ventana Producto";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBajaProducto;
        private System.Windows.Forms.Button btnModificacionProducto;
        private System.Windows.Forms.Button btnAltaProducto;
    }
}