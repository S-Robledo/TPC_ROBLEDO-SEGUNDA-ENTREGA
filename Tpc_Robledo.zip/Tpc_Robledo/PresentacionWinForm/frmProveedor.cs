﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentacionWinForm
{
    public partial class frmProveedor : Form
    {
        public frmProveedor()
        {
            InitializeComponent();
        }

        private void btnAltaProveedor_Click(object sender, EventArgs e)
        {
            frmAltaProveedor proveedorAlta = new frmAltaProveedor();
            proveedorAlta.ShowDialog();
        }

        private void btnModificacionProveedor_Click(object sender, EventArgs e)
        {
            frmModificarProveedor proveedorMofificar = new frmModificarProveedor();
            proveedorMofificar.ShowDialog();
        }

        private void btnBajaProveedor_Click(object sender, EventArgs e)
        {
            frmBajaProveedor proveedorBaja = new frmBajaProveedor();
            proveedorBaja.ShowDialog();
        }
    }
}
