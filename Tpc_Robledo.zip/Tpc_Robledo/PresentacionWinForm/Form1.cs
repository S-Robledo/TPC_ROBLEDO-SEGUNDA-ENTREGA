﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentacionWinForm
{
    public partial class frmVentanaMenuPrincipal : Form
    {
        public frmVentanaMenuPrincipal()
        {
            InitializeComponent();
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            frmCliente ventanaCliente = new frmCliente();
            ventanaCliente.ShowDialog();
        }

        private void btnProveedor_Click(object sender, EventArgs e)
        {
            frmProveedor ventanaProveedor = new frmProveedor();
            ventanaProveedor.ShowDialog();

        }
    }
}
