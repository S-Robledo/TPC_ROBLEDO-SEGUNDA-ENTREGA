﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Persona
    {
        public string Apellido { get; set; }
        public string Nombre { get; set; }
        public string Dni { get; set; }
        public Fecha fechaNacimiento { get; set; }
        public Nacionalidad Nacionalidad { get; set; }
        public Mail Mail { get; set; }
        public Telefono Telefono { get; set; }

    }
}
