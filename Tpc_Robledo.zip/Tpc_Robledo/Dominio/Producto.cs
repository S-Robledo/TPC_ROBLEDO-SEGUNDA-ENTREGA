﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Producto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public Marca Marca { get; set; }
        public Categoria Categoria { get; set; }
        public Proveedor proveedor { get; set; }
        public int stock { get; set; }
        public float PorcentajeGanancia { get; set; }
        public float PrecioLista { get; set; }
        public Fecha FechaVencimiento { get; set; }
    }
}
