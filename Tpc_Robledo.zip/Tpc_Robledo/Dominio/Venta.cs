﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Venta
    {
        public Fecha Fecha { get; set; }
        public Cliente Cliente { get; set; }
        public DetalleVenta DetalleVenta { get; set; }
        public float precioTotal { get; set; }
    }
}
