﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class DetalleVenta
    {
        public Producto Producto { get; set; }
        public int cantidadVendida { get; set; }
        public float precioUnitario { get; set; }
        public float precioParcial { get; set; }
    }
}
