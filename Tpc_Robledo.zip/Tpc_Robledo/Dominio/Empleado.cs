﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Empleado : Persona
    {
        public int Id { get; set; }
        public string Cuil { get; set; }
        public Direccion Direccion { get; set; }
        public string ObraSocial { get; set; }

    }
}
