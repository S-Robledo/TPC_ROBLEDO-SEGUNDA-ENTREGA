﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Telefono
    {
        public int Id { get; set; }
        //public  Tipotelefono { get; set; }
        public int Numero { get; set; }

    }
}
